"""init for pytiled_parser"""

from . import objects, utilities
from .xml_parser import parse_tile_map
